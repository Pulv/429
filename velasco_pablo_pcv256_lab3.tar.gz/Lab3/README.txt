The optimization that I made was when you input one variable/number, it immediately moves it to %rax and returns. Does not use stack.
